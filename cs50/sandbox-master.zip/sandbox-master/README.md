# Testing

```
make
```

# References

* https://support.rstudio.com/hc/en-us/articles/200552316-Configuring-the-Server
* http://docs.rstudio.com/ide/server-pro
