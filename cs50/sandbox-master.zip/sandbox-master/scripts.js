/* CS50 scripts.js */
